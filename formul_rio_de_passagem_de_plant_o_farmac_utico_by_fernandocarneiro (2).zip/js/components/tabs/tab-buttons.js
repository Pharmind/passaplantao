// Tab buttons template
export const TAB_BUTTONS = `
    <div class="tab-buttons">
        <button class="tab-btn active" data-tab="tab-satelites"><i class="fas fa-clinic-medical"></i> Satélites e Central</button>
        <button class="tab-btn" data-tab="tab-caf"><i class="fas fa-warehouse"></i> CAF</button>
    </div>
`;

